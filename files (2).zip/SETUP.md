# Chess Bot Website — Windows Setup + Render Deploy
=======================================================

## PART 1 — Run it on your computer (10 min)

### Step 1 — Install Python
1. Go to https://python.org/downloads
2. Download Python 3.11 (the big yellow button)
3. Run the installer — CHECK THE BOX that says "Add Python to PATH"
4. Click Install Now

### Step 2 — Install VS Code
1. Go to https://code.visualstudio.com
2. Download and install it (just click through the installer)

### Step 3 — Download Stockfish for Windows
1. Go to https://stockfishchess.org/download/
2. Click "Windows" → download the .zip file
3. Unzip it — find the file called stockfish.exe (or stockfish-windows-x86-64.exe)
4. Rename it to exactly: stockfish.exe
5. Put it in the chess-bot-website folder (same folder as main.py)

### Step 4 — Set up the project
1. Open VS Code
2. File → Open Folder → select the chess-bot-website folder
3. Open the Terminal in VS Code: View → Terminal (or Ctrl+`)
4. In the terminal, type these commands one at a time:

    pip install flask flask-cors python-chess gunicorn

### Step 5 — Run it!
In the VS Code terminal:

    python main.py

Then open your browser and go to:  http://localhost:8080

Your chess bot website is running! Every time you want to use it,
just open VS Code, open the terminal, and run python main.py.

---

## PART 2 — Put it on the internet with Render (15 min)

### Step 1 — Make a GitHub account
1. Go to https://github.com and sign up (free)

### Step 2 — Create a new repository
1. Click the + button top right → New repository
2. Name it: chess-bot
3. Set it to Public
4. Click Create repository

### Step 3 — Upload your files to GitHub
On the new repo page, click "uploading an existing file"
Upload all 5 files:
  - main.py
  - bot.py
  - requirements.txt
  - render.yaml
  - templates/index.html  (create the templates folder first)

Click Commit changes.

### Step 4 — Deploy on Render
1. Go to https://render.com and sign up with your GitHub account
2. Click New → Web Service
3. Connect your chess-bot GitHub repository
4. Render auto-detects the settings from render.yaml
5. Click Deploy

Render builds and deploys your app. Takes about 3-5 minutes.
When it's done you get a URL like:  https://chess-bot-xxxx.onrender.com

Share that link with anyone — it works from any browser!

### Step 5 — Update your site later
Whenever you edit bot.py or any file:
1. Re-upload the changed file to GitHub (or use GitHub Desktop)
2. Render automatically re-deploys — takes about 2 minutes

---

## File structure
chess-bot-website/
├── main.py          ← Flask server (don't edit much)
├── bot.py           ← YOUR BOT — edit this to make it smarter!
├── requirements.txt ← Python packages
├── render.yaml      ← Render deployment config
├── stockfish.exe    ← Download separately (Windows only, not on GitHub)
└── templates/
    └── index.html   ← The website frontend
